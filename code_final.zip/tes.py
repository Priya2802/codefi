m = 3; 
n = 3; 
 
def contribution_height(current, previous): 
	return abs(current - previous); 
 
def surfacearea(a): 
	ans = 0; 
 
	for i in range(n): 
		for j in range(m): 

			 
			up = 0; 

			
			left = 0; 

			if (i > 0): 
				up = a[i - 1][j]; 

			 
			if (j > 0): 
				left = a[i][j - 1]; 

			 
			ans += contribution_height(a[i][j], up)+contribution_height(a[i][j], left); 
			
			
			if (i == n - 1): 
				ans += a[i][j]; 

			if (j == m - 1): 
				ans += a[i][j]; 

	ans += n * m * 2; 
	return ans; 

a = [[1, 3, 4],[2, 2, 3],[1, 2, 4]]; 
print(surfacearea(a)); 

# This code is contributed By mits
